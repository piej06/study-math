package studymath;

/**
 * Stateless arithmetic operations for finite real-valued inputs.
 * Results use double precision and are not intended for exact currency accounting.
 */
public final class MathTools {
    /** Creates a reusable arithmetic helper with no mutable state. */
    public MathTools() { }

    /**
     * Adds two finite numbers.
     * @param a first number
     * @param b second number
     * @return a plus b
     */
    public double add(double a, double b) { finite(a,b); return checked(a+b); }

    /**
     * Subtracts the second number from the first.
     * @param a starting number
     * @param b number to subtract
     * @return a minus b
     */
    public double subtract(double a, double b) { finite(a,b); return checked(a-b); }

    /**
     * Multiplies two finite numbers.
     * @param a first factor
     * @param b second factor
     * @return their product
     */
    public double multiply(double a, double b) { finite(a,b); return checked(a*b); }

    /**
     * Divides a by a nonzero divisor.
     * @param a dividend
     * @param b divisor
     * @return the quotient
     * @throws ArithmeticException if b is zero
     */
    public double divide(double a, double b) {
        finite(a,b);
        if(b==0) throw new ArithmeticException("Cannot divide by zero.");
        return checked(a/b);
    }

    /**
     * Returns Java's remainder, whose sign follows the dividend.
     * @param a dividend
     * @param b nonzero divisor
     * @return the remainder
     * @throws ArithmeticException if b is zero
     */
    public double modulus(double a, double b) {
        finite(a,b);
        if(b==0) throw new ArithmeticException("Cannot find remainder with a zero divisor.");
        return checked(a%b);
    }

    /**
     * Raises a base to an exponent using Math.pow.
     * @param base base value
     * @param exponent power to apply
     * @return the power, including 1 for an exponent of zero
     * @throws ArithmeticException if the result is non-real or overflows
     */
    public double exponential(double base, double exponent) {
        finite(base,exponent);
        return checked(Math.pow(base,exponent));
    }

    /**
     * Finds the nonnegative square root of a finite nonnegative value.
     * @param value value whose root is needed
     * @return its square root
     * @throws ArithmeticException for a negative value
     */
    public double squareRoot(double value) {
        finite(value);
        if(value<0) throw new ArithmeticException("Cannot take the square root of a negative number.");
        return Math.sqrt(value);
    }

    /**
     * Calculates a percentage of a value, such as percentage(200,15) = 30.
     * @param value starting value
     * @param percent rate in percentage points, not a fraction
     * @return value multiplied by percent divided by 100
     */
    public double percentage(double value, double percent) {
        finite(value,percent);
        return checked(value*(percent/100.0));
    }

    // Reject invalid inputs consistently across the public operations.
    private static void finite(double... values) {
        for(double value:values) if(!Double.isFinite(value))
            throw new IllegalArgumentException("Inputs must be finite numbers.");
    }

    // Do not silently return NaN or infinity when a calculation fails.
    private static double checked(double value) {
        if(!Double.isFinite(value)) throw new ArithmeticException("Result is outside the finite real-number range.");
        return value;
    }
}
