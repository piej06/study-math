package studymath;

import java.io.InputStream;
import java.io.IOException;
import java.util.Properties;

/** Demonstrates using the same library API that other Java projects import. */
public final class Demo {
    private Demo() { }
    /**
     * Prints a few sample calculations from the packaged library.
     * @param args unused command-line arguments
     * @throws IOException if the version resource cannot be read
     */
    public static void main(String[] args) throws IOException {
        Properties version=new Properties();
        try(InputStream input=Demo.class.getResourceAsStream("/studymath.properties")) {
            if(input==null) throw new IOException("Missing library version resource.");
            version.load(input);
        }
        MathTools math=new MathTools();
        System.out.println("StudyMath "+version.getProperty("version"));
        System.out.println("2 + 3 = "+math.add(2,3));
        System.out.println("2 to the power of 3 = "+math.exponential(2,3));
        System.out.println("Square root of 9 = "+math.squareRoot(9));
        System.out.println("15 percent of 200 = "+math.percentage(200,15));
    }
}
