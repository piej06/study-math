package studymath;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import static org.junit.jupiter.api.Assertions.*;

@Timeout(2)
class ValidationTest {
    private final MathTools math=new MathTools();

    // All operations follow the same finite-input contract.
    @ParameterizedTest @ValueSource(doubles={Double.NaN,Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY})
    void invalidInputs_areRejectedByEveryOperation(double value) {
        assertAll(
            () -> assertThrows(IllegalArgumentException.class,()->math.add(value,1)),
            () -> assertThrows(IllegalArgumentException.class,()->math.subtract(1,value)),
            () -> assertThrows(IllegalArgumentException.class,()->math.multiply(value,1)),
            () -> assertThrows(IllegalArgumentException.class,()->math.divide(1,value)),
            () -> assertThrows(IllegalArgumentException.class,()->math.modulus(value,1)),
            () -> assertThrows(IllegalArgumentException.class,()->math.exponential(1,value)),
            () -> assertThrows(IllegalArgumentException.class,()->math.squareRoot(value)),
            () -> assertThrows(IllegalArgumentException.class,()->math.percentage(1,value)));
    }
    @Test void overflowingArithmetic_throwsInsteadOfReturningInfinity() {
        assertAll(
            () -> assertThrows(ArithmeticException.class,()->math.add(Double.MAX_VALUE,Double.MAX_VALUE)),
            () -> assertThrows(ArithmeticException.class,()->math.subtract(Double.MAX_VALUE,-Double.MAX_VALUE)),
            () -> assertThrows(ArithmeticException.class,()->math.multiply(Double.MAX_VALUE,2)),
            () -> assertThrows(ArithmeticException.class,()->math.divide(Double.MAX_VALUE,0.5)),
            () -> assertThrows(ArithmeticException.class,()->math.percentage(Double.MAX_VALUE,200)));
    }
    @Test void negativeZeroDivisor_isRejected() {
        assertThrows(ArithmeticException.class,()->math.divide(1,-0.0));
        assertThrows(ArithmeticException.class,()->math.modulus(1,-0.0));
    }
    @Test void versionResource_isIncluded() throws Exception {
        try(var stream=Demo.class.getResourceAsStream("/studymath.properties")) {
            assertNotNull(stream);var props=new java.util.Properties();props.load(stream);
            assertEquals("1.0.0",props.getProperty("version"));
        }
    }
}
