package studymath;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

@Timeout(2)
class MathToolsTest {
    private final MathTools calculator = new MathTools();
    private static final double DELTA = 0.000000001;

    // Each row checks an independently specified expected result.
    @ParameterizedTest @CsvSource({"2,3,5", "-2,3,1", "0,0,0", "0.1,0.2,0.3"})
    void add_validNumbers_returnsSum(double a, double b, double expected) { assertEquals(expected, calculator.add(a,b), DELTA); }
    @ParameterizedTest @CsvSource({"5,3,2", "3,5,-2", "-3,-2,-1"})
    void subtract_validNumbers_returnsDifference(double a, double b, double expected) { assertEquals(expected, calculator.subtract(a,b), DELTA); }
    @ParameterizedTest @CsvSource({"2,3,6", "-2,3,-6", "7,0,0"})
    void multiply_validNumbers_returnsProduct(double a, double b, double expected) { assertEquals(expected, calculator.multiply(a,b), DELTA); }
    @ParameterizedTest @CsvSource({"10,2,5", "7,2,3.5", "-9,3,-3", "0,2,0"})
    void divide_nonzeroDivisor_returnsQuotient(double a, double b, double expected) { assertEquals(expected, calculator.divide(a,b), DELTA); }
    @Test void divide_zeroDivisor_throwsHelpfulError() { assertEquals("Cannot divide by zero.", assertThrows(ArithmeticException.class, () -> calculator.divide(5,0)).getMessage()); }
    @ParameterizedTest @CsvSource({"10,3,1", "8,4,0", "-10,3,-1", "5.5,2,1.5"})
    void modulus_nonzeroDivisor_returnsRemainder(double a, double b, double expected) { assertEquals(expected, calculator.modulus(a,b), DELTA); }
    @Test void modulus_zeroDivisor_throwsError() { assertThrows(ArithmeticException.class, () -> calculator.modulus(5,0)); }
    @ParameterizedTest @CsvSource({"2,3,8", "5,0,1", "2,-2,0.25", "9,0.5,3", "-2,3,-8"})
    void exponential_validInputs_returnsPower(double a, double b, double expected) { assertEquals(expected, calculator.exponential(a,b), DELTA); }
    @Test void exponential_nonRealResult_throwsError() { assertThrows(ArithmeticException.class, () -> calculator.exponential(-4,0.5)); }
    @Test void exponential_overflow_throwsError() { assertThrows(ArithmeticException.class, () -> calculator.exponential(10,400)); }
    @ParameterizedTest @CsvSource({"9,3", "0,0", "0.25,0.5", "2,1.4142135623730951"})
    void squareRoot_nonnegativeInput_returnsRoot(double a, double expected) { assertEquals(expected, calculator.squareRoot(a), DELTA); }
    @Test void squareRoot_negativeInput_throwsError() { assertThrows(ArithmeticException.class, () -> calculator.squareRoot(-1)); }
    @ParameterizedTest @CsvSource({"200,15,30", "80,0,0", "80,100,80", "50,150,75", "-200,15,-30", "100,2.5,2.5"})
    void percentage_valueAndRate_returnsPortion(double a, double b, double expected) { assertEquals(expected, calculator.percentage(a,b), DELTA); }
}
