@echo off
cd /d "%~dp0"
java -jar dist/study-math-1.0.0.jar
