@echo off
setlocal
cd /d "%~dp0"
set "MAVEN_OPTS=%MAVEN_OPTS% -Djavax.net.ssl.trustStoreType=Windows-ROOT -Djavax.net.ssl.trustStore=NONE"
call mvnw.cmd -B install
exit /b %errorlevel%
