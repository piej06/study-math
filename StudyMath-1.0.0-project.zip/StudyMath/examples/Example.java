import studymath.MathTools;

public class Example {
    public static void main(String[] args) {
        MathTools math=new MathTools();
        System.out.println(math.percentage(200,15));
        System.out.println(math.exponential(2,3));
    }
}
